local noclip = false
local speed = 1.5

RegisterCommand('myranoclip', function()
    noclip = not noclip
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if noclip then
            local ped = PlayerPedId()
            local x, y, z = table.unpack(GetEntityCoords(ped))
            local dx, dy, dz = GetCamDirection()

            if IsControlPressed(0, 32) then -- W
                x = x + dx * speed
                y = y + dy * speed
                z = z + dz * speed
            end
            if IsControlPressed(0, 33) then -- S
                x = x - dx * speed
                y = y - dy * speed
                z = z - dz * speed
            end
            if IsControlPressed(0, 44) then -- Q
                z = z + speed
            end
            if IsControlPressed(0, 36) then -- CTRL
                z = z - speed
            end

            SetEntityCoordsNoOffset(ped, x, y, z, true, true, true)
            SetEntityVisible(ped, false, false)
            SetEntityInvincible(ped, true)
            FreezeEntityPosition(ped, true)
        else
            local ped = PlayerPedId()
            SetEntityVisible(ped, true, false)
            SetEntityInvincible(ped, false)
            FreezeEntityPosition(ped, false)
        end
    end
end)

function GetCamDirection()
    local heading = GetGameplayCamRelativeHeading() + GetEntityHeading(PlayerPedId())
    local pitch = GetGameplayCamRelativePitch()

    local x = -math.sin(math.rad(heading))
    local y = math.cos(math.rad(heading))
    local z = math.sin(math.rad(pitch))

    return x, y, z
end
