local QBCore = exports['qb-core']:GetCoreObject()

QBCore.Functions.CreateCallback("myra_noclip:isAdmin", function(source, cb)
    local Player = QBCore.Functions.GetPlayer(source)
    if Player and Player.PlayerData and Player.PlayerData.group then
        local group = Player.PlayerData.group
        if group == "admin" or group == "god" then
            cb(true)
            return
        end
    end
    cb(false)
end)
