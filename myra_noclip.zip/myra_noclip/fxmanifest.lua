fx_version 'cerulean'
game 'gta5'

author 'YourName'
description 'Sessiz Admin Noclip (F6)'
version '1.0.0'

client_script 'client.lua'
server_script 'server.lua'
